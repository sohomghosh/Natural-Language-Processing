Here I have analyzed the followung two files:
1) mispelt_removed_negative_reviews_tokenized_with_stopwords-removed_and_stemming_done.txt
2) mispelt_removed_positive_reviews_tokenized_with_stopwords-removed_and_stemming_done.txt

The corpus I used is:-
pos_complete.txt 
and
neg_complete.txt

OUTPUT:
analyzed_neg_reviews_new.txt
and
analyzed_pos_reviews_new.txt

The output files has a set of numbers. This number denote the positivity, negativity of the reviews. A negative value indicates the comment is negative. A positive value indicates the comment is positive. A zero value indicates either the comment is neutral/balanced or it has equal positive and negative words. The numeric value indicates the amount of positivity, negativity in the review.

P.S. The lines in 
analyzed_neg_reviews_new.txt 
and 
mispelt_removed_negative_reviews_tokenized_with_stopwords-removed_and_stemming_done.txt
are in sequence. Same is true for postive reviews.
That is line 1 in 
analyzed_neg_reviews_new.txt 
maps to
line 1 in
mispelt_removed_negative_reviews_tokenized_with_stopwords-removed_and_stemming_done.txt
and so on.